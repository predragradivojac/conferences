%finds the average of a matrix
function y = conference_average(matrix)
    y = mean(mean(matrix,1));
end