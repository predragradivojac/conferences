% By running 'Citation_Analysis.m' all conference paper citation data will
% be arranged by paper and by year. The average, median, and median of top
% ten papers will be calculated and appended to the appropriate matrix to
% be graphed using 'citation_bars.m'. Then the p-values will calculated
% using 'pvalmat.m'.
% 
% The above applies to 'Citation_analysis_2Year.m' except the matrices of
% citation data by year by paper only includes papers from the i+1 and i+2
% years.